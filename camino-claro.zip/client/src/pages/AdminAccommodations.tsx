import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "wouter";
import { ArrowLeft, Plus, Trash2, Edit2, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface Accommodation {
  id: number;
  name: string;
  type: string;
  location: string;
  stage: string | null;
  pricePerNight: number | null;
  description: string | null;
  services: string | null;
  website: string | null;
  phone: string | null;
  email: string | null;
  latitude: string | null;
  longitude: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export default function AdminAccommodations() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    type: "albergue" | "hostal" | "hotel" | "pension" | "otro";
    location: string;
    stage: string;
    pricePerNight: string;
    description: string;
    website: string;
    phone: string;
    email: string;
  }>({
    name: "",
    type: "albergue",
    location: "",
    stage: "",
    pricePerNight: "",
    description: "",
    website: "",
    phone: "",
    email: "",
  });

  const { data: accommodations, isLoading } = trpc.accommodations.list.useQuery();
  const createAccommodation = trpc.accommodations.create.useMutation();
  const updateAccommodation = trpc.accommodations.update.useMutation();
  const deleteAccommodation = trpc.accommodations.delete.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingId) {
        await updateAccommodation.mutateAsync({
          id: editingId,
          name: formData.name,
          type: formData.type as "albergue" | "hostal" | "hotel" | "pension" | "otro",
          location: formData.location,
          stage: formData.stage,
          pricePerNight: parseInt(formData.pricePerNight) || undefined,
          description: formData.description || undefined,
          website: formData.website || undefined,
          phone: formData.phone || undefined,
          email: formData.email || undefined,
        });
        toast.success("Alojamiento actualizado");
      } else {
        await createAccommodation.mutateAsync({
          name: formData.name,
          type: formData.type as "albergue" | "hostal" | "hotel" | "pension" | "otro",
          location: formData.location,
          stage: formData.stage,
          pricePerNight: parseInt(formData.pricePerNight) || undefined,
          description: formData.description || undefined,
          website: formData.website || undefined,
          phone: formData.phone || undefined,
          email: formData.email || undefined,
        });
        toast.success("Alojamiento creado");
      }

      setFormData({
        name: "",
        type: "albergue" as const,
        location: "",
        stage: "",
        pricePerNight: "",
        description: "",
        website: "",
        phone: "",
        email: "",
      });
      setEditingId(null);
      setShowForm(false);
    } catch (error) {
      toast.error("Error al guardar el alojamiento");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("¿Estás seguro de que deseas eliminar este alojamiento?")) {
      try {
        await deleteAccommodation.mutateAsync(id);
        toast.success("Alojamiento eliminado");
      } catch (error) {
        toast.error("Error al eliminar el alojamiento");
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-white dark:bg-card shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">Gestionar Alojamientos</h1>
          </div>
          <Button onClick={() => setShowForm(!showForm)} className="cta-button">
            <Plus className="h-4 w-4 mr-2" />
            Nuevo Alojamiento
          </Button>
        </div>
      </div>

      <div className="container py-8 flex-1">
        {/* Form */}
        {showForm && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>{editingId ? "Editar Alojamiento" : "Nuevo Alojamiento"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo *</Label>
                    <Select value={formData.type} onValueChange={(value: any) => setFormData({ ...formData, type: value })}>
                      <SelectTrigger id="type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="albergue">Albergue</SelectItem>
                        <SelectItem value="hostal">Hostal</SelectItem>
                        <SelectItem value="hotel">Hotel</SelectItem>
                        <SelectItem value="pension">Pensión</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación *</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="stage">Etapa *</Label>
                    <Input
                      id="stage"
                      placeholder="Ej: Etapa 3"
                      value={formData.stage}
                      onChange={(e) => setFormData({ ...formData, stage: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">Precio por Noche (€)</Label>
                    <Input
                      id="price"
                      type="number"
                      value={formData.pricePerNight}
                      onChange={(e) => setFormData({ ...formData, pricePerNight: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Sitio Web</Label>
                    <Input
                      id="website"
                      type="url"
                      value={formData.website}
                      onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                  />
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="cta-button">
                    {editingId ? "Actualizar" : "Crear"} Alojamiento
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowForm(false);
                      setEditingId(null);
                      setFormData({
                        name: "",
                        type: "albergue",
                        location: "",
                        stage: "",
                        pricePerNight: "",
                        description: "",
                        website: "",
                        phone: "",
                        email: "",
                      });
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Table */}
        <Card>
          <CardHeader>
            <CardTitle>Alojamientos ({accommodations?.length || 0})</CardTitle>
            <CardDescription>Gestiona los alojamientos disponibles en el Camino Francés</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : accommodations && accommodations.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Ubicación</TableHead>
                      <TableHead>Etapa</TableHead>
                      <TableHead>Precio</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accommodations.map((accommodation: Accommodation) => (
                      <TableRow key={accommodation.id}>
                        <TableCell className="font-medium">{accommodation.name}</TableCell>
                        <TableCell>{accommodation.type}</TableCell>
                        <TableCell>{accommodation.location}</TableCell>
                        <TableCell>{accommodation.stage}</TableCell>
                        <TableCell>{accommodation.pricePerNight ? `${accommodation.pricePerNight}€` : "N/A"}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingId(accommodation.id);
                              setFormData({
                                name: accommodation.name,
                                type: accommodation.type as "albergue" | "hostal" | "hotel" | "pension" | "otro",
                                location: accommodation.location,
                                stage: accommodation.stage || "",
                                pricePerNight: accommodation.pricePerNight?.toString() || "",
                                description: accommodation.description || "",
                                website: accommodation.website || "",
                                phone: accommodation.phone || "",
                                email: accommodation.email || "",
                              });
                              setShowForm(true);
                            }}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDelete(accommodation.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">No hay alojamientos registrados</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
