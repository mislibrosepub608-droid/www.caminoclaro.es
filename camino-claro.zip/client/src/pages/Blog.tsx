import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { ArrowLeft, Search, MapPin, DollarSign } from "lucide-react";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  stage: string;
  accommodationType: string;
  image: string;
  author: string;
  date: string;
}

const SAMPLE_BLOG_POSTS: BlogPost[] = [
  {
    id: 1,
    title: "Alojamientos en Pamplona: Guía Completa para Peregrinos",
    slug: "alojamientos-pamplona",
    excerpt: "Descubre las mejores opciones de alojamiento en Pamplona, desde albergues económicos hasta hoteles confortables...",
    stage: "Etapa 3",
    accommodationType: "Albergues y Hostales",
    image: "🏛️",
    author: "Camino Claro",
    date: "2026-02-20",
  },
  {
    id: 2,
    title: "Logroño: Descanso y Comodidad en La Rioja",
    slug: "alojamientos-logrono",
    excerpt: "Logroño es una parada perfecta en el Camino. Te mostramos dónde dormir y qué comer en esta hermosa ciudad...",
    stage: "Etapa 7",
    accommodationType: "Hoteles y Pensiones",
    image: "🏨",
    author: "Camino Claro",
    date: "2026-02-18",
  },
  {
    id: 3,
    title: "Burgos: Historia, Cultura y Buen Descanso",
    slug: "alojamientos-burgos",
    excerpt: "Burgos es una de las ciudades más importantes del Camino. Aquí encontrarás opciones de alojamiento para todos los presupuestos...",
    stage: "Etapa 12",
    accommodationType: "Albergues, Hostales y Hoteles",
    image: "🏰",
    author: "Camino Claro",
    date: "2026-02-15",
  },
  {
    id: 4,
    title: "León: Descanso en una Ciudad Medieval",
    slug: "alojamientos-leon",
    excerpt: "León ofrece una parada perfecta para recuperarse. Descubre los mejores alojamientos y servicios para peregrinos...",
    stage: "Etapa 20",
    accommodationType: "Albergues y Hoteles",
    image: "⛪",
    author: "Camino Claro",
    date: "2026-02-12",
  },
  {
    id: 5,
    title: "O Cebreiro: Alojamiento en la Montaña",
    slug: "alojamientos-cebreiro",
    excerpt: "O Cebreiro es una aldea mágica en la montaña. Aquí te mostramos dónde dormir en este lugar especial del Camino...",
    stage: "Etapa 26",
    accommodationType: "Albergues de Montaña",
    image: "⛰️",
    author: "Camino Claro",
    date: "2026-02-10",
  },
  {
    id: 6,
    title: "Santiago de Compostela: Llegada y Celebración",
    slug: "alojamientos-santiago",
    excerpt: "Has llegado a Santiago. Aquí encontrarás opciones de alojamiento para celebrar tu llegada a la meta del Camino...",
    stage: "Etapa 33",
    accommodationType: "Hoteles y Albergues",
    image: "🎉",
    author: "Camino Claro",
    date: "2026-02-08",
  },
];

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStage, setSelectedStage] = useState<string | null>(null);

  const filteredPosts = SAMPLE_BLOG_POSTS.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStage = !selectedStage || post.stage === selectedStage;
    return matchesSearch && matchesStage;
  });

  const stages = Array.from(new Set(SAMPLE_BLOG_POSTS.map((p) => p.stage)));

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-white dark:bg-card shadow-sm">
        <div className="container flex items-center gap-4 h-16">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Blog - Alojamientos del Camino</h1>
        </div>
      </div>

      <div className="container py-8 flex-1">
        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex gap-4 flex-col md:flex-row">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Buscar artículos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Stage Filter */}
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedStage === null ? "default" : "outline"}
              onClick={() => setSelectedStage(null)}
              size="sm"
            >
              Todas las Etapas
            </Button>
            {stages.map((stage) => (
              <Button
                key={stage}
                variant={selectedStage === stage ? "default" : "outline"}
                onClick={() => setSelectedStage(stage)}
                size="sm"
              >
                {stage}
              </Button>
            ))}
          </div>
        </div>

        {/* Blog Posts Grid */}
        {filteredPosts.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`}>
                <Card className="blog-card h-full cursor-pointer hover:scale-105 transition-transform">
                  <CardContent className="pt-6">
                    <div className="text-5xl mb-4">{post.image}</div>
                    <h3 className="text-lg font-bold mb-2 line-clamp-2">{post.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{post.excerpt}</p>

                    <div className="space-y-2 text-xs text-muted-foreground mb-4">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {post.stage}
                      </div>
                      <div className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        {post.accommodationType}
                      </div>
                    </div>

                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>{post.author}</span>
                      <span>{new Date(post.date).toLocaleDateString("es-ES")}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No se encontraron artículos que coincidan con tu búsqueda.</p>
            <Button onClick={() => { setSearchTerm(""); setSelectedStage(null); }} variant="outline">
              Limpiar filtros
            </Button>
          </div>
        )}

        {/* CTA Section */}
        <div className="mt-16 bg-accent text-accent-foreground rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">¿Necesitas Ayuda Personalizada?</h2>
          <p className="mb-6">
            Nuestro equipo puede ayudarte a encontrar el alojamiento perfecto para tu viaje.
          </p>
          <Link href="/contacto">
            <Button variant="outline" className="bg-accent-foreground text-accent hover:bg-accent-foreground/90">
              Solicitar Asesoramiento
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
