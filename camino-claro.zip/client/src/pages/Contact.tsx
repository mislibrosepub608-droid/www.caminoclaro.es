import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { ArrowLeft, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    serviceType: "general_inquiry" as const,
    description: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const createConsultation = trpc.consultations.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await createConsultation.mutateAsync({
        name: formData.name,
        email: formData.email,
        phone: formData.phone || undefined,
        serviceType: formData.serviceType,
        description: formData.description || undefined,
      });

      setSubmitted(true);
      toast.success("Consulta enviada correctamente");
      setFormData({
        name: "",
        email: "",
        phone: "",
        serviceType: "general_inquiry",
        description: "",
      });

      setTimeout(() => {
        setSubmitted(false);
      }, 5000);
    } catch (error) {
      toast.error("Error al enviar la consulta");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const serviceDescriptions: Record<string, { label: string; price: string }> = {
    orientation_consultation: {
      label: "Consulta de Orientación",
      price: "5-10€",
    },
    stage_planning: {
      label: "Planificación de Siguiente Etapa",
      price: "10-15€",
    },
    accommodation_search: {
      label: "Búsqueda y Ayuda de Alojamiento",
      price: "15-25€",
    },
    complete_management: {
      label: "Gestión Puntual Más Completa",
      price: "25-30€",
    },
    angel_del_camino: {
      label: "El Ángel del Camino - Asistencia WhatsApp",
      price: "25€ (1-10 días)",
    },
    anti_masificacion: {
      label: "Planificador de Etapas: Anti-Masificación",
      price: "Personalizado",
    },
    general_inquiry: {
      label: "Consulta General",
      price: "A consultar",
    },
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-white dark:bg-card shadow-sm">
        <div className="container flex items-center gap-4 h-16">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Contacto</h1>
        </div>
      </div>

      <div className="container py-8 flex-1">
        <div className="grid lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Envíanos tu Consulta</CardTitle>
                <CardDescription>Completa el formulario y nos pondremos en contacto contigo</CardDescription>
              </CardHeader>
              <CardContent>
                {submitted ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
                    <h3 className="text-xl font-bold mb-2">¡Consulta Enviada!</h3>
                    <p className="text-muted-foreground mb-4">
                      Hemos recibido tu consulta. Nos pondremos en contacto contigo pronto.
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Puedes esperar respuesta en las próximas 24-48 horas.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Name */}
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre *</Label>
                      <Input
                        id="name"
                        placeholder="Tu nombre completo"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="tu@email.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>

                    {/* Phone */}
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono (Opcional)</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+34 XXX XXX XXX"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>

                    {/* Service Type */}
                    <div className="space-y-2">
                      <Label htmlFor="service">Tipo de Servicio *</Label>
                      <Select value={formData.serviceType} onValueChange={(value: any) => setFormData({ ...formData, serviceType: value })}>
                        <SelectTrigger id="service">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general_inquiry">Consulta General</SelectItem>
                          <SelectItem value="orientation_consultation">Consulta de Orientación (5-10€)</SelectItem>
                          <SelectItem value="stage_planning">Planificación de Etapa (10-15€)</SelectItem>
                          <SelectItem value="accommodation_search">Búsqueda de Alojamiento (15-25€)</SelectItem>
                          <SelectItem value="complete_management">Gestión Completa (25-30€)</SelectItem>
        <SelectItem value="angel_del_camino">El Ángel del Camino - WhatsApp (25€)</SelectItem>
        <SelectItem value="anti_masificacion">Planificador Anti-Masificación</SelectItem>
                        </SelectContent>
                      </Select>
                      {formData.serviceType !== "general_inquiry" && (
                        <div className="mt-3 p-3 bg-accent/10 rounded-lg border border-accent/20">
                          <p className="text-sm font-semibold text-accent">
                            Precio estimado: {serviceDescriptions[formData.serviceType]?.price}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            El precio final se confirmará en la consulta
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Description */}
                    <div className="space-y-2">
                      <Label htmlFor="description">Mensaje *</Label>
                      <Textarea
                        id="description"
                        placeholder="Cuéntanos qué necesitas..."
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        required
                        rows={6}
                      />
                    </div>

                    {/* Disclaimer */}
                    <div className="disclaimer-box">
                      <AlertCircle className="h-4 w-4 inline mr-2" />
                      <p className="text-sm inline">
                        <strong>Importante:</strong> Se informa del precio en la consulta. Los precios mostrados son orientativos.
                      </p>
                    </div>
                    <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
                      <p className="text-sm text-yellow-900 dark:text-yellow-100">
                        <strong>NO SOMOS AGENCIA NI CENTRAL DE RESERVAS</strong> - Somos un servicio de orientación y apoyo para peregrinos
                      </p>
                    </div>

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full cta-button"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Enviando...
                        </>
                      ) : (
                        "Enviar Consulta"
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Contact Info Sidebar */}
          <div className="space-y-6">
            {/* Direct Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contacto Directo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Email</p>
                  <a href="mailto:caminoclaro78@gmail.com" className="text-accent font-semibold hover:underline">
                    caminoclaro78@gmail.com
                  </a>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Teléfono</p>
                  <a href="tel:+34692576302" className="text-accent font-semibold hover:underline">
                    +34 692 576 302
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Service Prices */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Nuestros Servicios</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(serviceDescriptions).map(([key, { label, price }]) => (
                  <div key={key} className="text-sm">
                    <p className="font-semibold text-foreground">{label}</p>
                    <p className="text-accent font-bold">{price}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Important Info */}
            <Card className="border-yellow-400 bg-yellow-50 dark:bg-yellow-950">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                  Importante
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-yellow-900 dark:text-yellow-100 space-y-2">
                <p>✓ No somos empresa turística</p>
                <p>✓ No realizamos reservas</p>
                <p>✓ Servicio de orientación y apoyo</p>
                <p>✓ Precio informado en consulta</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
