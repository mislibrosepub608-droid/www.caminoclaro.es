import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { MapPin, MessageCircle, Calculator, BookOpen, Phone, Mail, AlertCircle, Compass, Heart } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Disclaimer Banner */}
      <div className="disclaimer-banner">
        ⚠️ NO SOMOS EMPRESA TURÍSTICA - SERVICIO DE ORIENTACIÓN Y APOYO - NO AGENCIA NI CENTRAL DE RESERVAS
      </div>

      {/* Navigation */}
      <nav className="bg-white dark:bg-card shadow-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <img src="/logo-camino-claro.png" alt="Camino Claro" className="h-16 w-auto" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">Camino Claro</h1>
              <p className="text-sm text-muted-foreground">Orientación para Peregrinos</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Link href="#servicios">
              <Button variant="ghost">Servicios</Button>
            </Link>
            <Link href="/blog">
              <Button variant="ghost">Blog</Button>
            </Link>
            <Link href="/calculadora">
              <Button variant="ghost">Calculadora</Button>
            </Link>
            <Link href="#contacto">
              <Button className="bg-accent hover:bg-accent/90">Contacto</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section with Background */}
      <section className="relative hero-section overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{
            backgroundImage: "url('/paisaje-galicia.jpg')",
            backgroundAttachment: 'fixed'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/70 to-background" />
        
        <div className="container py-24 text-center relative z-10">
          <div className="mb-8 flex justify-center">
            <img src="/logo-camino-claro.png" alt="Camino Claro Logo" className="h-56 w-auto drop-shadow-2xl" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-foreground drop-shadow-md">
            Camino Claro
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto drop-shadow-md">
            Tu guía de confianza para el Camino Francés. Orientación, asesoramiento y apoyo para peregrinos en cada paso de tu viaje.
          </p>
          
          <div className="flex gap-4 justify-center flex-wrap mb-8">
            <Link href="/chatbot">
              <Button className="cta-button" size="lg">
                <MessageCircle className="mr-2" />
                Hablar con IA
              </Button>
            </Link>
            <Link href="/calculadora">
              <Button variant="outline" size="lg">
                <Calculator className="mr-2" />
                Calcular Etapas
              </Button>
            </Link>
          </div>

          {/* Pilgrimage Icons */}
          <div className="flex justify-center gap-8 mt-12 flex-wrap">
            <div className="text-center">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/cyhBdEuAYsYBAWQWCe9iMy-img-1_1771923224000_na1fn_Y29uY2hhLXNhbnRpYWdv.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L2N5aEJkRXVBWXNZQkFXUVdDZTlpTXktaW1nLTFfMTc3MTkyMzIyNDAwMF9uYTFmbl9ZMjl1WTJoaExYTmhiblJwWVdkdi5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=nDow9RJJZHZ8DqtU4ugJWJKiIw6b782T-jWQ8L~-i~SnkfFlIyvrMfIlte0qFQ98JjxZFtwmfxTcZTMO2qvjraiBCUewwHOqimbZYO39znxdPHZHmKMWHkq6cFtMWr4BleOFh-fHsLEP1~ONG5KxHeBnBtUW2-SfyBE7sU7kavQcwnfR2of9gqRnUAEEF3iV9LAgwQS9uwyLx7Mva3JgNcs-pFlN5seVUX141d7HNoiuNIN9XFEjqKuUbfSY6wcWnA60f7Ofn9VvHzFX77LNB7RSqQ2xZ2avuna2BUff5SkQZu3F7YRhRYH3gwjQsb2C-x~bTUGQb9ib007G6evjXw__" alt="Concha" className="h-16 w-16 mx-auto mb-2" />
              <p className="text-sm font-semibold">Símbolo del Camino</p>
            </div>
            <div className="text-center">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/cyhBdEuAYsYBAWQWCe9iMy-img-2_1771923223000_na1fn_bW9jaGlsYS1wZXJlZ3Jpbm8.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L2N5aEJkRXVBWXNZQkFXUVdDZTlpTXktaW1nLTJfMTc3MTkyMzIyMzAwMF9uYTFmbl9iVzlqYUdsc1lTMXdaWEpsWjNKcGJtOC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=TKNBwaNxFL-QA1ypqndLJne~VqtglwOlVPadpLZ9IkFSKs9GT1YpiwDutlM6OdCy6NABf-l8k4tnBVmYfYN0QT2CvQBLbiHb1453z~Q5vFj0wk-LbHANS~1ioew9lCPtiyTLsWVxb2isTJdI4BiWjhmp9xhQDH844g7izlkf-E6EUShumuRioCRSptX6LVDVJYgQtuOuudNI71xOYUT-yi4liIg2QgnA3-ljU06guKnrEnaDkIJwnslLz~~2UhGehs0a9Kd~pwYMt9S3rxWjwLSLd8frtjwCsdYI33wkXhb5oZVaEvCeC8tjGsxnb8-o7Sse7FzSOfCOL~GR6LZznw__" alt="Mochila" className="h-16 w-16 mx-auto mb-2" />
              <p className="text-sm font-semibold">Equipamiento</p>
            </div>
            <div className="text-center">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/cyhBdEuAYsYBAWQWCe9iMy-img-3_1771923223000_na1fn_cGVyZWdyaW5vLXNpbHVldGE.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L2N5aEJkRXVBWXNZQkFXUVdDZTlpTXktaW1nLTNfMTc3MTkyMzIyMzAwMF9uYTFmbl9jR1Z5WldkeWFXNXZMWE5wYkhWbGRHRS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=CWhUeZcWrgszkgZlfoEPip~rV0qcuuUM1U32cXYz5qbFGtCPfLsNp5JjVdeZkCS-PlMGl6WpzFezSP2yQnLu3V44qoom0wDAD2Z8TPA3J3N~Jh5UWmn~zJuZEtMTjbp9yx8paMsiPi5YDOMlllCePPTuj3RORmeaZf46qsWXgzdA2jw161jLb1VfTtp6AiiqA0UGE9DkrgpCor7MjnYne~9k243ymOvRwzdq6fK-aofv8mJG1CJLSeWtC2QHUtw1Pl0BnZq2Vp2XP6AUm4X4vTJAYxWtv7L1f-ISdwEXAz4BsGTa6lyy3sTDXiRfgyDFlYv4Kb6mDIFRZ3zkOePmDw__" alt="Peregrino" className="h-16 w-16 mx-auto mb-2" />
              <p className="text-sm font-semibold">Tu Viaje</p>
            </div>
          </div>
        </div>
      </section>

      {/* Disclaimer Box */}
      <section className="container py-8">
        <div className="disclaimer-box">
          <div className="flex gap-3">
            <AlertCircle className="h-6 w-6 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold mb-2">Importante: Quiénes Somos</h3>
              <p className="text-sm mb-2">
                <strong>NO somos una empresa turística ni una agencia de viajes.</strong> Camino Claro es un servicio de orientación y apoyo para peregrinos del Camino Francés.
              </p>
              <p className="text-sm">
                <strong>SE INFORMA DEL PRECIO EN LA CONSULTA.</strong> Nuestro objetivo es ayudarte a planificar tu peregrinación de forma segura y consciente.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="container py-16">
        <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Nuestros Servicios</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Service 1 */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-accent" />
                Consulta de Orientación
              </CardTitle>
              <CardDescription>5-10€</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Respuestas sobre el Camino, etapas, alojamientos y consejos para peregrinos.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Service 2 */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-accent" />
                Planificación de Etapa
              </CardTitle>
              <CardDescription>10-15€</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Ayuda personalizada para planificar tu siguiente etapa del Camino.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Service 3 */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-accent" />
                Búsqueda de Alojamiento
              </CardTitle>
              <CardDescription>15-25€</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Recomendaciones de alojamientos según tus preferencias y presupuesto.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Service 4 */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Compass className="h-5 w-5 text-accent" />
                Gestión Completa
              </CardTitle>
              <CardDescription>25-30€</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Planificación integral de tu viaje: etapas, alojamientos y logística.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Service 5 - El Ángel del Camino */}
          <Card className="hover:shadow-lg transition-shadow border-2 border-accent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-accent" />
                El Ángel del Camino
              </CardTitle>
              <CardDescription>25€ (1-10 días)</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-2 font-semibold text-accent">Asistencia por WhatsApp</p>
              <p className="text-sm mb-4">Bono de asistencia durante tu peregrinación. Resuelve cualquier duda o problema en tiempo real por WhatsApp.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Service 6 - Planificador Anti-Masificación */}
          <Card className="hover:shadow-lg transition-shadow border-2 border-accent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Compass className="h-5 w-5 text-accent" />
                Planificador de Etapas
              </CardTitle>
              <CardDescription>Personalizado</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-2 font-semibold text-accent">Anti-Masificación</p>
              <p className="text-sm mb-4">Planificación personalizada basada en tu ritmo físico y gustos. Evita multitudes y disfruta del Camino a tu ritmo.</p>
              <Link href="/contacto">
                <Button variant="outline" size="sm" className="w-full">Solicitar</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="container py-16">
        <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Lo Que Dicen Nuestros Peregrinos</h2>
        
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="overflow-hidden">
            <div className="relative">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/6LxnjW3GI2LgnAbOZqyVMC-img-1_1771926131000_na1fn_dGVzdGltb25pby1tYXJpYQ.jpg?x-oss-process=image/resize,w_500,h_500/format,webp/quality,q_80" alt="María García" className="w-full h-64 object-cover" />
            </div>
            <CardContent className="pt-6">
              <div className="flex items-center gap-1 mb-3">
                {'⭐'.repeat(5)}
              </div>
              <p className="text-muted-foreground mb-4">"Camino Claro me ayudó a planificar cada etapa perfectamente. El chatbot IA respondió todas mis preguntas sobre alojamientos y rutas. ¡Excelente servicio!"</p>
              <p className="font-semibold">María García</p>
              <p className="text-sm text-muted-foreground">Peregrino desde Roncesvalles</p>
            </CardContent>
          </Card>

          <Card className="overflow-hidden">
            <div className="relative">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/6LxnjW3GI2LgnAbOZqyVMC-img-2_1771926129000_na1fn_dGVzdGltb25pby1qdWFu.jpg?x-oss-process=image/resize,w_500,h_500/format,webp/quality,q_80" alt="Juan López" className="w-full h-64 object-cover" />
            </div>
            <CardContent className="pt-6">
              <div className="flex items-center gap-1 mb-3">
                {'⭐'.repeat(5)}
              </div>
              <p className="text-muted-foreground mb-4">"No sabía cómo organizar mi viaje, pero con la calculadora de etapas y la orientación de Camino Claro todo fue muy fácil. ¡Lo recomiendo!"</p>
              <p className="font-semibold">Juan López</p>
              <p className="text-sm text-muted-foreground">Peregrino desde Francia</p>
            </CardContent>
          </Card>

          <Card className="overflow-hidden">
            <div className="relative">
              <img src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/6LxnjW3GI2LgnAbOZqyVMC-img-3_1771926131000_na1fn_dGVzdGltb25pby1hbmE.jpg?x-oss-process=image/resize,w_500,h_500/format,webp/quality,q_80" alt="Ana Martínez" className="w-full h-64 object-cover" />
            </div>
            <CardContent className="pt-6">
              <div className="flex items-center gap-1 mb-3">
                {'⭐'.repeat(5)}
              </div>
              <p className="text-muted-foreground mb-4">"El equipo de Camino Claro me brindó un apoyo increíble durante todo mi peregrinación. Llegué a Santiago con confianza y seguridad."</p>
              <p className="font-semibold">Ana Martínez</p>
              <p className="text-sm text-muted-foreground">Peregrino desde Pamplona</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="bg-muted/50 py-16">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Galería del Camino Francés</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow h-64">
              <img 
                src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/toRKNgibMbAnnTJuz3rssz-img-1_1771924176000_na1fn_Y2FtaW5vLXBhaXNhamU.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L3RvUktOZ2liTWJBbm5USnV6M3Jzc3otaW1nLTFfMTc3MTkyNDE3NjAwMF9uYTFmbl9ZMkZ0YVc1dkxYQmhhWE5oYW1VLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=N7kquIZdQjn5QEFyLaecbHs7UVQCWQHhM3EcpnQwO~CnzGawNxAjV9RZHY9dZT70V5dx6awY1cNOl9zpcSp5VM~IEgvGiU2mnB6rutDAi~SWNM81QQ5cSBjQtORw20DimeC9QyYp74bf60lD5lI4F4QNBMAzVqRZPvG3MW7YJPI-NpZDfCcufR11I2vu3zRNQOhp9O2dOndSJQRWfier-nMHlDX2exfOiyyKE9ILOS05Fv7B3zSnp~YW9mjUMXGYcFV9rjupPsA-WoJ753nul1zqPXTaOgg0L3uQez31US~5Zyijx60tCy3ozURoBgAox94H-HsILyExU~vAjclXYg__" 
                alt="Paisajes del Camino Francés" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
                <p className="font-semibold">Paisajes del Camino</p>
                <p className="text-sm">Vistas espectaculares de la ruta</p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow h-64">
              <img 
                src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/toRKNgibMbAnnTJuz3rssz-img-2_1771924162000_na1fn_Y2FtaW5vLXB1ZWJsb3M.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L3RvUktOZ2liTWJBbm5USnV6M3Jzc3otaW1nLTJfMTc3MTkyNDE2MjAwMF9uYTFmbl9ZMkZ0YVc1dkxYQjFaV0pzYjNNLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=UDmtnXj-mMsnF3UoO9lle-1YfqYTj1ZzF-U0ypF~eliTSfKwBjTVB3qT5nMxgqGfw5scqArA~BYbnaOrJrpUTsm0Vsx3iuUqljd47dEW1VhQgkOI5CgL7MAxktbbOPGXrg6iBsOJ6OA7vYEXR1jm3tkKz4moWDePBIhCzCi2BsAEzx57BKCdhNM6max3W1L-RUqtG8AUQOQLRdPk60yYtGdW5t0IEkXugw3bbd~Be52QSQORTiNutuI8ULSFv6xs3oty1cbGt6baweLMBbjH3TEdCcnj-G12BijN5PNTfSXy8MwiQJFIqFEviM~5dzG~LFkYfBvpzl6S36PlFvamGQ__" 
                alt="Pueblos y Ciudades del Camino" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
                <p className="font-semibold">Pueblos y Ciudades</p>
                <p className="text-sm">Patrimonio histórico del Camino</p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow h-64">
              <img 
                src="https://private-us-east-1.manuscdn.com/sessionFile/31El4oiLokwsQkHg9KrThM/sandbox/toRKNgibMbAnnTJuz3rssz-img-3_1771924165000_na1fn_Y2FtaW5vLWlnbGVzaWFz.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMzFFbDRvaUxva3dzUWtIZzlLclRoTS9zYW5kYm94L3RvUktOZ2liTWJBbm5USnV6M3Jzc3otaW1nLTNfMTc3MTkyNDE2NTAwMF9uYTFmbl9ZMkZ0YVc1dkxXbG5iR1Z6YVdGei5qcGc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=ubhMIZN4Y8gzm05Oy5Pk~pIS2zaKPDn3lE1MivzNp4~mAdL7xo1Vbsy~VFZ4t4gu-hBhcoA8PdqfSwyQA4OpOA1IG0KAuWGSrgKoptw59n0qkQk6X2E1~hoX9WVNyRxNT5JpegRe68WR-6kfI-M-pJzRAWB4tKCTFO8JQ0ukkdZklUvBRcVgwC9-IyxHilHk-aJxQIhJdmamXUCwrLol5YkiJ4DdIP6~UAc65SfIpmYGVE8sBLITJX30mCui3mzDiayjA-Xyjtrx7f1RQRkV57aoYdjg5xRQ8KsAjVsr7~OgAp6QNcg7oT~4wGW0axUnyxZJcw7uBxCZj4MJZubD4A__" 
                alt="Iglesias y Templos del Camino" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
                <p className="font-semibold">Iglesias y Templos</p>
                <p className="text-sm">Lugares de fe en el Camino</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-muted/50 py-16">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">¿Por Qué Elegirnos?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-5xl mb-4">🤖</div>
              <h3 className="text-xl font-bold mb-2">Chatbot IA 24/7</h3>
              <p className="text-muted-foreground">Respuestas inmediatas a tus preguntas sobre el Camino Francés en cualquier momento.</p>
            </div>
            
            <div className="text-center">
              <div className="text-5xl mb-4">📊</div>
              <h3 className="text-xl font-bold mb-2">Calculadora Inteligente</h3>
              <p className="text-muted-foreground">Planifica tu ruta según distancia, dificultad y tiempo disponible.</p>
            </div>
            
            <div className="text-center">
              <div className="text-5xl mb-4">📚</div>
              <h3 className="text-xl font-bold mb-2">Blog Informativo</h3>
              <p className="text-muted-foreground">Artículos detallados sobre alojamientos y consejos prácticos para peregrinos.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="container py-16">
        <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Mapa del Camino Francés</h2>
        
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-gradient-to-br from-green-100 to-blue-100 h-96 flex items-center justify-center relative">
              <div className="text-center">
                <div className="text-6xl mb-4">🗺️</div>
                <h3 className="text-2xl font-bold mb-4">Camino Francés: 33 Etapas</h3>
                <p className="text-muted-foreground mb-6 max-w-md">Desde Saint-Jean-Pied-de-Port (Francia) hasta Santiago de Compostela (España)</p>
                <p className="text-sm text-muted-foreground mb-4">Distancia total: 760-930 km | Duración: 30-35 días</p>
                <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto text-sm">
                  <div>
                    <p className="font-semibold">Inicio</p>
                    <p className="text-muted-foreground">Saint-Jean-Pied-de-Port</p>
                  </div>
                  <div>
                    <p className="font-semibold">Ruta</p>
                    <p className="text-muted-foreground">Por Pamplona y Burgos</p>
                  </div>
                  <div>
                    <p className="font-semibold">Fin</p>
                    <p className="text-muted-foreground">Santiago de Compostela</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Etapas Destacadas</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>• <strong>Etapa 1:</strong> Roncesvalles - Zubiri (22 km)</li>
                <li>• <strong>Etapa 5:</strong> Pamplona - Puente la Reina (24 km)</li>
                <li>• <strong>Etapa 12:</strong> Frómista - Carrión de los Condes (19 km)</li>
                <li>• <strong>Etapa 20:</strong> Mansilla de las Mulas - León (37 km)</li>
                <li>• <strong>Etapa 33:</strong> Pedrouzo - Santiago de Compostela (20 km)</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Información Práctica</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>• <strong>Mejor época:</strong> Abril-Mayo y Septiembre-Octubre</li>
                <li>• <strong>Dificultad:</strong> Moderada a Alta</li>
                <li>• <strong>Alojamientos:</strong> Albergues, hostales y hoteles</li>
                <li>• <strong>Documentación:</strong> Credencial del peregrino</li>
                <li>• <strong>Clima:</strong> Variable según la región</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-muted/50 py-16">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Preguntas Frecuentes</h2>
          
          <div className="max-w-3xl mx-auto space-y-4">
            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Cuál es la mejor época para hacer el Camino Francés?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">La mejor época es abril-mayo y septiembre-octubre. Durante estos meses el clima es más agradable, hay menos lluvia y la naturaleza está en su esplendor. Evita julio-agosto por el calor excesivo y la masificación de peregrinos.</p>
            </details>

            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Cuánto tiempo se necesita para completar el Camino?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">El Camino Francés tiene 780 km y normalmente se completa en 30-35 días caminando entre 20-25 km diarios. Sin embargo, puedes adaptar el ritmo según tu condición física y disponibilidad de tiempo. Nuestra calculadora de etapas te ayuda a personalizar tu ruta.</p>
            </details>

            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Qué documentación necesito?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">Necesitas la Credencial del Peregrino (documento que acredita tu peregrinación), pasaporte o DNI válido, y un seguro de viaje recomendado. La credencial se obtiene en parroquias, asociaciones de amigos del Camino o en línea. Te ayudamos a gestionar toda la documentación necesaria.</p>
            </details>

            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Cuál es la diferencia entre vuestros servicios y una agencia de viajes?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">Somos un servicio de orientación y apoyo, NO una agencia de viajes. No hacemos reservas de alojamientos ni vendemos paquetes turísticos. Proporcionamos asesoramiento personalizado, planificación de rutas, información sobre alojamientos y apoyo durante tu peregrinación.</p>
            </details>

            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Cómo funcionan vuestros precios?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">Nuestros precios son orientativos y se confirman en la consulta inicial. Ofrecemos desde consultas rápidas (5-10€) hasta gestión completa de tu peregrinación (25-30€). Cada servicio se personaliza según tus necesidades específicas.</p>
            </details>

            <details className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-background/50 transition">
              <summary className="flex items-center justify-between font-semibold text-lg text-foreground">
                <span>¿Puedo contactar con vosotros durante mi peregrinación?</span>
                <span className="group-open:rotate-180 transition">▼</span>
              </summary>
              <p className="mt-4 text-muted-foreground">¡Por supuesto! Puedes contactarnos por email, teléfono o WhatsApp en cualquier momento durante tu viaje. Nuestro chatbot IA está disponible 24/7 para responder preguntas inmediatas, y nuestro equipo humano te atiende para consultas más complejas.</p>
            </details>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="container py-16">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">Ponte en Contacto</h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-center gap-2">
                  <Mail className="h-5 w-5 text-accent" />
                  Email
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-accent">caminoclaro78@gmail.com</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-center gap-2">
                  <Phone className="h-5 w-5 text-accent" />
                  Teléfono
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold text-accent">+34 692 576 302</p>
              </CardContent>
            </Card>
          </div>

          <Link href="/contacto">
            <Button className="cta-button" size="lg">
              Enviar Consulta
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 border-t border-border mt-16">
        <div className="container py-8 text-center text-muted-foreground text-sm">
          <p className="mb-2">© 2026 Camino Claro - Asesoría del Camino Francés desde Palás de Rei</p>
          <p>Servicio de Orientación y Apoyo para Peregrinos - NO Agencia de Viajes</p>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/34692576302"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition-all duration-300 hover:scale-110 flex items-center justify-center"
        title="Contactar por WhatsApp"
      >
        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.946 1.347l-.355.203-.368-.066c-1.286-.264-2.514-.666-3.554-1.259l-.621-.378-.6.179C2.97 6.438 1 8.507 1 10.897c0 2.6 1.409 5.012 3.85 6.66l.531.338-.079.609c-.231 1.75.046 3.479.422 5.042.637 2.632 1.787 5.127 3.465 7.193h.003c.342.376.773.863 1.3 1.467 1.847-.504 3.594-1.529 5.106-3.07 1.542-1.57 2.846-3.414 3.841-5.44.449-.88.741-1.837.864-2.752.146-1.081.146-2.41 0-3.49-.31-2.75-1.155-5.12-2.573-7.066C15.886 3.5 12.877 1.979 9.51 1.979z"/>
        </svg>
      </a>
    </div>
  );
}
