import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Link } from "wouter";
import { ArrowLeft, MapPin, Clock, TrendingUp } from "lucide-react";

interface StageResult {
  stageNumber: number;
  name: string;
  distance: number;
  difficulty: number;
  estimatedDays: number;
}

interface Stage {
  number: number;
  name: string;
  distance: number;
  difficulty: number;
}

const STAGES: Stage[] = [
  { number: 1, name: "Saint-Jean-Pied-de-Port → Roncesvalles", distance: 24.2, difficulty: 5 },
  { number: 2, name: "Roncesvalles → Zubiri", distance: 21.4, difficulty: 3 },
  { number: 3, name: "Zubiri → Pamplona", distance: 20.4, difficulty: 1 },
  { number: 4, name: "Pamplona → Puente la Reina", distance: 23.9, difficulty: 2 },
  { number: 5, name: "Puente la Reina → Estella", distance: 21.6, difficulty: 2 },
  { number: 6, name: "Estella → Los Arcos", distance: 21.3, difficulty: 2 },
  { number: 7, name: "Los Arcos → Logroño", distance: 27.6, difficulty: 2 },
  { number: 8, name: "Logroño → Nájera", distance: 29.0, difficulty: 2 },
  { number: 9, name: "Nájera → Santo Domingo de la Calzada", distance: 20.7, difficulty: 1 },
  { number: 10, name: "Santo Domingo de la Calzada → Belorado", distance: 22.0, difficulty: 1 },
  { number: 11, name: "Belorado → San Juan de Ortega", distance: 23.9, difficulty: 2 },
  { number: 12, name: "San Juan de Ortega → Burgos", distance: 25.8, difficulty: 2 },
  { number: 13, name: "Burgos → Hornillos del Camino", distance: 20.3, difficulty: 2 },
  { number: 14, name: "Hornillos del Camino → Castrojeriz", distance: 19.9, difficulty: 2 },
  { number: 15, name: "Castrojeriz → Frómista", distance: 24.7, difficulty: 2 },
  { number: 16, name: "Frómista → Carrión de los Condes", distance: 18.8, difficulty: 1 },
  { number: 17, name: "Carrión de los Condes → Terradillos de los Templarios", distance: 26.3, difficulty: 2 },
  { number: 18, name: "Terradillos de los Templarios → Bercianos del Real Camino", distance: 23.2, difficulty: 2 },
  { number: 19, name: "Bercianos del Real Camino → Mansilla de las Mulas", distance: 26.3, difficulty: 2 },
  { number: 20, name: "Mansilla de las Mulas → León", distance: 18.4, difficulty: 1 },
  { number: 21, name: "León → San Martín del Camino", distance: 24.6, difficulty: 2 },
  { number: 22, name: "San Martín del Camino → Astorga", distance: 23.7, difficulty: 2 },
  { number: 23, name: "Astorga → Foncebadón", distance: 25.8, difficulty: 2 },
  { number: 24, name: "Foncebadón → Ponferrada", distance: 26.8, difficulty: 3 },
  { number: 25, name: "Ponferrada → Villafranca del Bierzo", distance: 23.2, difficulty: 2 },
  { number: 26, name: "Villafranca del Bierzo → O Cebreiro", distance: 27.8, difficulty: 4 },
  { number: 27, name: "O Cebreiro → Triacastela", distance: 20.6, difficulty: 2 },
  { number: 28, name: "Triacastela → Sarria", distance: 17.8, difficulty: 2 },
  { number: 29, name: "Sarria → Portomarín", distance: 22.2, difficulty: 2 },
  { number: 30, name: "Portomarín → Palas de Rei", distance: 24.8, difficulty: 2 },
  { number: 31, name: "Palas de Rei → Arzúa", distance: 28.5, difficulty: 3 },
  { number: 32, name: "Arzúa → O Pedrouzo", distance: 19.3, difficulty: 2 },
  { number: 33, name: "O Pedrouzo → Santiago de Compostela", distance: 19.4, difficulty: 2 },
] as const;

export default function StageCalculator() {
  const [startStage, setStartStage] = useState("1");
  const [endStage, setEndStage] = useState("33");
  const [dailyDistance, setDailyDistance] = useState([25]);
  const [difficulty, setDifficulty] = useState("all");
  const [results, setResults] = useState<StageResult[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleCalculate = () => {
    const start = parseInt(startStage);
    const end = parseInt(endStage);

    if (start > end) {
      alert("La etapa de inicio debe ser menor que la etapa final");
      return;
    }

    const selectedStages: Stage[] = STAGES.filter((s) => s.number >= start && s.number <= end);

    let filteredStages: Stage[] = selectedStages;
    if (difficulty !== "all") {
      const diffLevel = parseInt(difficulty);
      filteredStages = selectedStages.filter((s) => s.difficulty === diffLevel);
    }

    const totalDistance = filteredStages.reduce((sum, s) => sum + s.distance, 0);
    const estimatedDays = Math.ceil(totalDistance / dailyDistance[0]);

    const stageResults: StageResult[] = filteredStages.map((stage) => ({
      stageNumber: stage.number,
      name: stage.name,
      distance: stage.distance,
      difficulty: stage.difficulty,
      estimatedDays: Math.ceil(stage.distance / dailyDistance[0]),
    })) as StageResult[];

    setResults(stageResults);
    setShowResults(true);
  };

  const totalDistance = results.reduce((sum, s) => sum + s.distance, 0);
  const totalDays = results.reduce((sum, s) => sum + s.estimatedDays, 0);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-white dark:bg-card shadow-sm">
        <div className="container flex items-center gap-4 h-16">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Calculadora de Etapas</h1>
        </div>
      </div>

      <div className="container py-8 flex-1">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calculator Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Planifica tu Ruta</CardTitle>
                <CardDescription>Configura los parámetros de tu viaje</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Start Stage */}
                <div className="space-y-2">
                  <Label htmlFor="start-stage">Etapa de Inicio</Label>
                  <Select value={startStage} onValueChange={setStartStage}>
                    <SelectTrigger id="start-stage">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STAGES.map((stage) => (
                        <SelectItem key={stage.number} value={stage.number.toString()}>
                          Etapa {stage.number}: {stage.name.split("→")[0]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* End Stage */}
                <div className="space-y-2">
                  <Label htmlFor="end-stage">Etapa Final</Label>
                  <Select value={endStage} onValueChange={setEndStage}>
                    <SelectTrigger id="end-stage">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STAGES.map((stage) => (
                        <SelectItem key={stage.number} value={stage.number.toString()}>
                          Etapa {stage.number}: {stage.name.split("→")[1]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Daily Distance */}
                <div className="space-y-2">
                  <Label>Distancia Diaria: {dailyDistance[0]} km</Label>
                  <Slider
                    value={dailyDistance}
                    onValueChange={setDailyDistance}
                    min={10}
                    max={40}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground">
                    {dailyDistance[0] <= 15 && "Ritmo lento (ideal para disfrutar)"}
                    {dailyDistance[0] > 15 && dailyDistance[0] <= 25 && "Ritmo moderado (recomendado)"}
                    {dailyDistance[0] > 25 && "Ritmo rápido (requiere buena forma)"}
                  </p>
                </div>

                {/* Difficulty Filter */}
                <div className="space-y-2">
                  <Label htmlFor="difficulty">Dificultad</Label>
                  <Select value={difficulty} onValueChange={setDifficulty}>
                    <SelectTrigger id="difficulty">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las dificultades</SelectItem>
                      <SelectItem value="1">Fácil (1)</SelectItem>
                      <SelectItem value="2">Moderada (2)</SelectItem>
                      <SelectItem value="3">Difícil (3)</SelectItem>
                      <SelectItem value="4">Muy Difícil (4)</SelectItem>
                      <SelectItem value="5">Extremadamente Difícil (5)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={handleCalculate} className="w-full cta-button">
                  Calcular Ruta
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            {showResults && results.length > 0 ? (
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid md:grid-cols-3 gap-4">
                  <Card className="service-card">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <MapPin className="h-5 w-5 text-accent" />
                        <span className="text-sm text-muted-foreground">Distancia Total</span>
                      </div>
                      <p className="text-2xl font-bold text-accent">{totalDistance.toFixed(1)} km</p>
                    </CardContent>
                  </Card>

                  <Card className="service-card">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-5 w-5 text-accent" />
                        <span className="text-sm text-muted-foreground">Días Estimados</span>
                      </div>
                      <p className="text-2xl font-bold text-accent">{totalDays} días</p>
                    </CardContent>
                  </Card>

                  <Card className="service-card">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-5 w-5 text-accent" />
                        <span className="text-sm text-muted-foreground">Promedio Diario</span>
                      </div>
                      <p className="text-2xl font-bold text-accent">{(totalDistance / totalDays).toFixed(1)} km</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Stages List */}
                <Card>
                  <CardHeader>
                    <CardTitle>Desglose de Etapas ({results.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {results.map((stage) => (
                        <div key={stage.stageNumber} className="stage-card">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-semibold text-sm">{stage.name}</h4>
                            <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded">
                              Etapa {stage.stageNumber}
                            </span>
                          </div>
                          <div className="flex gap-4 text-sm text-muted-foreground">
                            <span>📍 {stage.distance} km</span>
                            <span>⏱️ {stage.estimatedDays} día{stage.estimatedDays > 1 ? "s" : ""}</span>
                            <span>📈 Dificultad: {stage.difficulty}/5</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Contact CTA */}
                <Card className="bg-accent text-accent-foreground">
                  <CardContent className="pt-6">
                    <p className="mb-4">
                      ¿Necesitas ayuda personalizada para planificar tu viaje? Nuestro equipo puede asesorarte sobre alojamientos, provisiones y consejos prácticos.
                    </p>
                    <Link href="/#contacto">
                      <Button variant="outline" className="bg-accent-foreground text-accent hover:bg-accent-foreground/90">
                        Solicitar Asesoramiento
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    Configura los parámetros de tu ruta y haz clic en "Calcular Ruta" para ver el desglose de etapas.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
