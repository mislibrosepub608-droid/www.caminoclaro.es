# Investigación: Camino Francés

## Información General

El **Camino Francés** es la ruta más importante del Camino de Santiago, caracterizada por:

- **Relevancia histórica**: Confluencia de las principales vías medievales de peregrinación europeas
- **Punto de inicio**: Puede ser Saint-Jean-Pied-de-Port (Francia) o Roncesvalles (España)
- **Distancia total**: Aproximadamente 760-930 km (según la fuente y punto de inicio)
- **Número de etapas**: 33 etapas aproximadamente
- **Distancia promedio por etapa**: 23-25 km
- **Patrimonio**: Inscrito como Patrimonio de la Humanidad por la UNESCO desde 1993
- **Características**: Variedad paisajística, extraordinaria riqueza monumental, pero con masificación

## Etapas del Camino Francés (desde Roncesvalles)

### Etapas iniciales (Navarra)
1. Saint-Jean-Pied-de-Port → Roncesvalles: 24,2 km (Ruta de Napoleón) o 23,4 km (por Valcarlos)
2. Roncesvalles → Zubiri: 21,4 km
3. Zubiri → Pamplona: 20,4 km
4. Pamplona → Puente la Reina: 23,9 km
5. Puente la Reina → Estella: 21,6 km

### Etapas de La Rioja y Castilla y León
6. Estella → Los Arcos: 21,3 km
7. Los Arcos → Logroño: 27,6 km
8. Logroño → Nájera: 29,0 km
9. Nájera → Santo Domingo de la Calzada: 20,7 km
10. Santo Domingo de la Calzada → Belorado: 22,0 km
11. Belorado → San Juan de Ortega: 23,9 km
12. San Juan de Ortega → Burgos: 25,8 km
13. Burgos → Hornillos del Camino: 20,3 km
14. Hornillos del Camino → Castrojeriz: 19,9 km
15. Castrojeriz → Frómista: 24,7 km
16. Frómista → Carrión de los Condes: 18,8 km
17. Carrión de los Condes → Terradillos de los Templarios: 26,3 km
18. Terradillos de los Templarios → Bercianos del Real Camino: 23,2 km
19. Bercianos del Real Camino → Mansilla de las Mulas: 26,3 km
20. Mansilla de las Mulas → León: 18,4 km

### Etapas de León
21. León → San Martín del Camino: 24,6 km (o Villar de Mazarife: 21,1 km)
22. San Martín del Camino → Astorga: 23,7 km (o desde Villar de Mazarife: 31,4 km)
23. Astorga → Foncebadón: 25,8 km
24. Foncebadón → Ponferrada: 26,8 km
25. Ponferrada → Villafranca del Bierzo: 23,2 km
26. Villafranca del Bierzo → O Cebreiro: 27,8 km (etapa difícil, cruza montaña)

### Etapas de Galicia
27. O Cebreiro → Triacastela: 20,6 km
28. Triacastela → Sarria: 17,8 km (por San Xil) o 24,7 km (por Samos)
29. Sarria → Portomarín: 22,2 km
30. Portomarín → Palas de Rei: 24,8 km
31. Palas de Rei → Arzúa: 28,5 km
32. Arzúa → O Pedrouzo: 19,3 km
33. O Pedrouzo → Santiago de Compostela: 19,4 km

## Dificultad de las Etapas

Las etapas están clasificadas por dificultad (del 1 al 5):
- **Nivel 1**: Fácil (ej: Zubiri-Pamplona, Santo Domingo-Belorado)
- **Nivel 2**: Moderada (mayoría de etapas)
- **Nivel 3**: Difícil (ej: Roncesvalles-Zubiri, Palas de Rei-Arzúa)
- **Nivel 4**: Muy difícil (ej: Saint-Jean-Roncesvalles por Napoleón, Villafranca-O Cebreiro)
- **Nivel 5**: Extremadamente difícil (ej: Saint-Jean-Roncesvalles por Napoleón)

## Regiones Atravesadas

1. **Francia**: Desde Saint-Jean-Pied-de-Port
2. **Navarra**: Roncesvalles, Pamplona, Puente la Reina, Estella
3. **La Rioja**: Logroño, Nájera, Santo Domingo de la Calzada
4. **Castilla y León**: Burgos, Palencia, Valladolid, León
5. **Galicia**: Ponferrada, O Cebreiro, Sarria, Arzúa, Santiago de Compostela

## Variantes del Camino Francés

- **Camino Francés por Aragón**: Alternativa que pasa por Aragón
- **Camino de Tours (Vía Turonensis)**: Desde París o Tours, una de las cuatro grandes rutas desde Francia
- **Vía Lemovicensis**: Desde Vézelay
- **Vía Podiensis**: Desde Le Puy
- **Vía Tolosana**: Desde Arles

## Información Práctica

- **Mejor época**: Primavera (abril-mayo) y otoño (septiembre-octubre)
- **Duración típica**: 30-35 días caminando
- **Alojamiento**: Albergues, hostales, hoteles disponibles en todas las etapas
- **Credencial**: Necesaria para acceso a albergues y para obtener la Compostela
- **Desnivel**: Variable según la etapa, con cruces de montaña significativos (Pirineos, O Cebreiro)

## Puntos de Interés Destacados

- **Roncesvalles**: Colegiata histórica
- **Pamplona**: Capital de Navarra, catedral, murallas
- **Logroño**: Capital de La Rioja
- **Burgos**: Catedral gótica, patrimonio histórico
- **León**: Catedral gótica, patrimonio medieval
- **Ponferrada**: Castillo templario
- **O Cebreiro**: Aldea de montaña con iglesia románica
- **Santiago de Compostela**: Catedral, destino final

## Datos Clave para la Calculadora

- Distancia total: 760-930 km
- Número de etapas: 33
- Distancia promedio: 23-25 km por etapa
- Rango de distancias diarias: 17,8 km a 31,4 km
- Dificultad: Varía de 1 a 5 según la etapa
- Desnivel: Especialmente en Pirineos y O Cebreiro
