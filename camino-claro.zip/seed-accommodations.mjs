import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;

const accommodationsData = [
  {
    name: "Albergue de Roncesvalles",
    type: "albergue",
    location: "Roncesvalles",
    stage: "Etapa 1",
    pricePerNight: 12,
    description: "Albergue tradicional con servicios básicos",
    services: JSON.stringify(["cama", "ducha", "comida"]),
    website: "https://www.roncesvalles.org",
    phone: "+34 948 760 000",
    email: "info@roncesvalles.org",
    latitude: "43.0167",
    longitude: "-1.3333",
  },
  {
    name: "Albergue Zubiri",
    type: "albergue",
    location: "Zubiri",
    stage: "Etapa 2",
    pricePerNight: 10,
    description: "Albergue acogedor en el corazón de Navarra",
    services: JSON.stringify(["cama", "ducha", "cocina"]),
    website: "https://www.albergue-zubiri.com",
    phone: "+34 948 304 052",
    email: "info@zubiri.com",
    latitude: "43.0500",
    longitude: "-1.5000",
  },
  {
    name: "Hotel Maisonnave",
    type: "hotel",
    location: "Pamplona",
    stage: "Etapa 3",
    pricePerNight: 65,
    description: "Hotel de 3 estrellas en el centro de Pamplona",
    services: JSON.stringify(["habitación privada", "desayuno", "wifi", "recepción 24h"]),
    website: "https://www.hotelmaisonnave.com",
    phone: "+34 948 222 600",
    email: "reservas@maisonnave.com",
    latitude: "42.8125",
    longitude: "-1.6458",
  },
  {
    name: "Albergue Pamplona",
    type: "albergue",
    location: "Pamplona",
    stage: "Etapa 3",
    pricePerNight: 13,
    description: "Albergue moderno con servicios completos",
    services: JSON.stringify(["cama", "ducha", "cocina", "lavandería"]),
    website: "https://www.albergue-pamplona.es",
    phone: "+34 948 121 396",
    email: "info@albergue-pamplona.es",
    latitude: "42.8125",
    longitude: "-1.6458",
  },
  {
    name: "Hotel Marqués de Vallejo",
    type: "hotel",
    location: "Logroño",
    stage: "Etapa 7",
    pricePerNight: 55,
    description: "Hotel boutique en la zona antigua de Logroño",
    services: JSON.stringify(["habitación privada", "desayuno", "wifi", "bar"]),
    website: "https://www.marquesdevallejo.com",
    phone: "+34 941 244 455",
    email: "info@marquesdevallejo.com",
    latitude: "42.4627",
    longitude: "-2.4449",
  },
  {
    name: "Albergue Logroño",
    type: "albergue",
    location: "Logroño",
    stage: "Etapa 7",
    pricePerNight: 11,
    description: "Albergue bien situado con buenas instalaciones",
    services: JSON.stringify(["cama", "ducha", "cocina", "sala común"]),
    website: "https://www.albergue-logrono.com",
    phone: "+34 941 254 812",
    email: "info@albergue-logrono.com",
    latitude: "42.4627",
    longitude: "-2.4449",
  },
  {
    name: "Hotel Silken Gran Teatro",
    type: "hotel",
    location: "Burgos",
    stage: "Etapa 12",
    pricePerNight: 75,
    description: "Hotel 4 estrellas frente a la Catedral de Burgos",
    services: JSON.stringify(["habitación privada", "desayuno", "wifi", "restaurante", "spa"]),
    website: "https://www.hoteles-silken.com",
    phone: "+34 947 252 500",
    email: "burgos@silken.com",
    latitude: "42.3438",
    longitude: "-3.6969",
  },
  {
    name: "Albergue Burgos",
    type: "albergue",
    location: "Burgos",
    stage: "Etapa 12",
    pricePerNight: 12,
    description: "Albergue moderno cerca de la catedral",
    services: JSON.stringify(["cama", "ducha", "cocina", "lavandería", "wifi"]),
    website: "https://www.albergue-burgos.es",
    phone: "+34 947 461 952",
    email: "info@albergue-burgos.es",
    latitude: "42.3438",
    longitude: "-3.6969",
  },
  {
    name: "Hotel San Marcos",
    type: "hotel",
    location: "León",
    stage: "Etapa 20",
    pricePerNight: 85,
    description: "Hotel de lujo en un convento histórico",
    services: JSON.stringify(["habitación privada", "desayuno", "wifi", "restaurante", "piscina"]),
    website: "https://www.parador.es/es/paradores/parador-de-leon",
    phone: "+34 987 237 300",
    email: "leon@parador.es",
    latitude: "42.5987",
    longitude: "-5.5794",
  },
  {
    name: "Albergue León",
    type: "albergue",
    location: "León",
    stage: "Etapa 20",
    pricePerNight: 11,
    description: "Albergue bien equipado en el centro de León",
    services: JSON.stringify(["cama", "ducha", "cocina", "sala común", "wifi"]),
    website: "https://www.albergue-leon.com",
    phone: "+34 987 251 545",
    email: "info@albergue-leon.com",
    latitude: "42.5987",
    longitude: "-5.5794",
  },
  {
    name: "Albergue O Cebreiro",
    type: "albergue",
    location: "O Cebreiro",
    stage: "Etapa 26",
    pricePerNight: 10,
    description: "Albergue de montaña con vistas espectaculares",
    services: JSON.stringify(["cama", "ducha", "comida", "calefacción"]),
    website: "https://www.albergue-cebreiro.com",
    phone: "+34 982 151 001",
    email: "info@cebreiro.com",
    latitude: "42.6667",
    longitude: "-7.1667",
  },
  {
    name: "Hospedería San Giraldo",
    type: "hotel",
    location: "O Cebreiro",
    stage: "Etapa 26",
    pricePerNight: 45,
    description: "Hospedería tradicional con encanto",
    services: JSON.stringify(["habitación privada", "desayuno", "comida", "calefacción"]),
    website: "https://www.hospederiasangiraldo.com",
    phone: "+34 982 151 162",
    email: "info@sangiraldo.com",
    latitude: "42.6667",
    longitude: "-7.1667",
  },
  {
    name: "Hotel Monumental",
    type: "hotel",
    location: "Santiago de Compostela",
    stage: "Etapa 33",
    pricePerNight: 95,
    description: "Hotel de lujo frente a la Catedral",
    services: JSON.stringify(["habitación privada", "desayuno", "wifi", "restaurante", "terraza"]),
    website: "https://www.hotelmonumental.com",
    phone: "+34 981 585 100",
    email: "reservas@monumental.com",
    latitude: "42.8806",
    longitude: "-8.5456",
  },
  {
    name: "Albergue Santiago",
    type: "albergue",
    location: "Santiago de Compostela",
    stage: "Etapa 33",
    pricePerNight: 12,
    description: "Albergue para celebrar la llegada al destino",
    services: JSON.stringify(["cama", "ducha", "cocina", "sala común", "wifi"]),
    website: "https://www.albergue-santiago.es",
    phone: "+34 981 569 942",
    email: "info@albergue-santiago.es",
    latitude: "42.8806",
    longitude: "-8.5456",
  },
];

async function seedAccommodations() {
  let connection;
  try {
    connection = await mysql.createConnection(DATABASE_URL);
    
    console.log("Insertando datos de alojamientos...");

    for (const accommodation of accommodationsData) {
      const query = `
        INSERT INTO accommodations (
          name, type, location, stage, pricePerNight, description, 
          services, website, phone, email, latitude, longitude
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const values = [
        accommodation.name,
        accommodation.type,
        accommodation.location,
        accommodation.stage,
        accommodation.pricePerNight,
        accommodation.description,
        accommodation.services,
        accommodation.website,
        accommodation.phone,
        accommodation.email,
        accommodation.latitude,
        accommodation.longitude,
      ];

      await connection.execute(query, values);
      console.log(`✓ Insertado: ${accommodation.name}`);
    }

    console.log("\n✅ Datos de alojamientos insertados correctamente");
  } catch (error) {
    console.error("❌ Error al insertar datos:", error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

seedAccommodations();
