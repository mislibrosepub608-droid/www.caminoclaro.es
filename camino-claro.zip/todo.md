# Camino Claro - Project TODO

## Base de Datos
- [x] Crear tabla de alojamientos con campos: nombre, ubicación, tipo, precio, servicios, descripción
- [x] Crear tabla de artículos del blog con campos: título, contenido, autor, fecha, etapa, alojamientos relacionados
- [x] Crear tabla de consultas/solicitudes de usuarios con campos: nombre, email, tipo de servicio, descripción, estado, fecha
- [x] Crear tabla de etapas del Camino Francés con información: nombre, distancia, dificultad, puntos de interés
- [x] Crear tabla de notificaciones al propietario para registrar solicitudes de servicios

## Interfaz de Usuario - Estructura General
- [x] Diseñar y crear layout principal con navegación
- [x] Crear header con logo de Camino Claro y navegación principal
- [x] Crear footer con información de contacto y avisos legales
- [x] Implementar avisos destacados sobre "NO SOMOS EMPRESA TURÍSTICA" en páginas clave
- [x] Implementar avisos sobre "SERVICIO DE ORIENTACIÓN Y APOYO - NO AGENCIA NI CENTRAL DE RESERVAS"
- [x] Implementar aviso "SE INFORMA DEL PRECIO EN LA CONSULTA"

## Página de Inicio
- [x] Crear hero section con presentación de Camino Claro
- [x] Crear sección de servicios principales con enlaces
- [x] Crear sección de testimonios o características destacadas
- [x] Crear sección "Últimos artículos del blog"
- [x] Crear CTA (Call To Action) para contactar

## Chatbot IA
- [x] Integrar API de LLM para chatbot
- [x] Crear componente de chat con historial de mensajes
- [x] Implementar prompts específicos para información del Camino Francés
- [x] Crear interfaz de chat flotante o en página dedicada
- [x] Implementar respuestas sobre etapas, alojamientos, consejos para peregrinos
- [x] Agregar opción para escalar consultas a contacto directo

## Calculadora de Etapas
- [x] Crear página de calculadora de etapas
- [x] Implementar selector de punto de inicio y fin del Camino
- [x] Implementar selector de distancia diaria deseada
- [x] Implementar selector de dificultad (fácil, moderada, difícil)
- [x] Implementar selector de tiempo disponible
- [x] Crear lógica para calcular ruta óptima basada en parámetros
- [x] Mostrar resultados con detalles de etapas, distancias y alojamientos sugeridos
- [ ] Permitir exportar o guardar plan de viaje

## Blog de Alojamientos
- [x] Crear página de listado de artículos del blog
- [ ] Crear página de detalle de artículo
- [x] Implementar filtros por etapa del Camino
- [x] Implementar filtros por tipo de alojamiento
- [x] Implementar búsqueda de artículos
- [ ] Crear formulario para agregar nuevos artículos (admin)
- [ ] Mostrar información de alojamientos recomendados en cada artículo

## Sección de Servicios y Precios
- [x] Crear página de servicios con descripción clara de cada uno
- [x] Mostrar precios: Consulta orientación (5-10€), Planificación etapa (10-15€), Búsqueda alojamiento (15-25€), Gestión completa (25-30€)
- [x] Implementar avisos destacados sobre "SE INFORMA DEL PRECIO EN LA CONSULTA"
- [x] Crear botones CTA para solicitar cada servicio
- [x] Implementar formulario de solicitud de servicio
- [ ] Agregar servicio "El Ángel del Camino" (asistencia WhatsApp 1-10 días por 25€)
- [ ] Agregar servicio "Planificador de Etapas: Anti-Masificación" (planificación personalizada)
- [ ] Actualizar formulario de contacto para incluir nuevos servicios

## Página de Contacto
- [x] Crear página de contacto con formulario
- [x] Implementar campos: nombre, email, teléfono, tipo de consulta, mensaje
- [x] Mostrar email: caminoclaro78@gmail.com
- [x] Mostrar teléfono: +34692576302
- [x] Implementar envío de formulario a base de datos
- [x] Implementar notificación al propietario cuando se reciba una consulta

## Notificaciones al Propietario
- [x] Implementar sistema de notificaciones cuando se reciba una solicitud de servicio
- [x] Implementar sistema de notificaciones cuando se reciba una consulta de contacto
- [ ] Crear panel de administración para ver notificaciones y solicitudes
- [ ] Implementar marcado de solicitudes como "leído" o "respondido"

## Avisos Legales y Disclaimers
- [x] Agregar aviso "NO SOMOS EMPRESA TURÍSTICA" en página de inicio
- [x] Agregar aviso "NO AGENCIA NI CENTRAL DE RESERVAS" en sección de servicios
- [x] Agregar aviso "SERVICIO DE ORIENTACIÓN Y APOYO" en página de contacto
- [x] Agregar aviso "SE INFORMA DEL PRECIO EN LA CONSULTA" en formularios de solicitud
- [ ] Crear página de términos y condiciones
- [ ] Crear página de política de privacidad

## Gestión de Contenido
- [ ] Crear panel de administración para gestionar alojamientos
- [ ] Crear panel de administración para gestionar artículos del blog
- [ ] Crear panel de administración para gestionar etapas del Camino
- [ ] Crear panel de administración para ver y responder consultas de usuarios

## Testing y Validación
- [ ] Escribir tests unitarios para funciones de cálculo de etapas
- [ ] Escribir tests para procedimientos de tRPC
- [ ] Probar chatbot con preguntas comunes sobre el Camino
- [ ] Probar calculadora de etapas con diferentes parámetros
- [ ] Probar formularios de contacto y solicitud de servicios
- [ ] Validar que los avisos legales sean visibles en todas las páginas clave
- [ ] Probar notificaciones al propietario

## Optimización y Despliegue
- [ ] Optimizar imágenes y assets
- [ ] Implementar SEO básico (meta tags, sitemap)
- [ ] Probar responsividad en dispositivos móviles
- [ ] Realizar pruebas de rendimiento
- [ ] Crear checkpoint final antes de publicar


## Mejoras Sugeridas - Fase 2

### 1. Integración de Datos Reales de Alojamientos
- [x] Agregar datos de alojamientos reales del Camino Francés a la base de datos
- [x] Crear script para poblar la base de datos con alojamientos por etapa
- [ ] Conectar la calculadora de etapas con datos de alojamientos
- [ ] Mostrar alojamientos sugeridos en los resultados de la calculadora

### 2. Panel de Administración para Gestionar Contenido
- [x] Crear página de admin con autenticación protegida (estructura básica)
- [x] Crear CRUD para gestionar alojamientos (estructura creada)
- [ ] Crear CRUD para gestionar artículos del blog
- [ ] Crear vista de consultas recibidas de peregrinos
- [ ] Implementar marcado de consultas como "leído" o "respondido"
- [ ] Crear formulario para agregar nuevos artículos del blog

### 3. Mejora del Chatbot con Integración de Datos
- [x] Conectar chatbot con base de datos de alojamientos
- [x] Conectar chatbot con base de datos de etapas
- [x] Permitir que el chatbot proporcione información específica de alojamientos
- [x] Permitir que el chatbot sugiera etapas basadas en preferencias
- [x] Mejorar respuestas del chatbot con datos en tiempo real


## Mejoras Sugeridas - Fase 3

### 1. Testimonios de Peregrinos
- [ ] Crear sección de testimonios en la página de inicio
- [ ] Agregar base de datos para almacenar testimonios
- [ ] Crear formulario para que peregrinos envíen testimonios
- [ ] Mostrar testimonios con avatar, nombre y calificación

### 2. Mapa Interactivo del Camino Francés
- [ ] Integrar Google Maps en la web
- [ ] Mostrar las 33 etapas del Camino Francés
- [ ] Marcar ubicaciones de alojamientos en el mapa
- [ ] Permitir filtrar por tipo de alojamiento
- [ ] Mostrar información de etapas al hacer clic

### 3. Galería de Fotos del Camino
- [ ] Crear página de galería de fotos
- [ ] Generar/recopilar fotos del Camino Francés
- [ ] Organizar fotos por etapas
- [ ] Agregar efecto lightbox para ver fotos en grande
- [ ] Permitir compartir fotos en redes sociales
